import 'package:flutter/material.dart';

import 'package:jansof/screens/actionappbar.dart';
import 'package:jansof/screens/animattedappbar.dart';
import 'package:jansof/screens/checking.dart';
import 'package:jansof/screens/dashboard.dart';
import 'package:jansof/screens/dynamicappbar.dart';
import 'package:jansof/screens/dynamics.dart';
import 'package:jansof/screens/flexiblespace.dart';
import 'package:jansof/screens/flexspaceappbar.dart';
import 'package:jansof/screens/herotransition/screens/home.dart';
import 'package:jansof/screens/home.dart';
import 'package:jansof/screens/homescreen.dart';
import 'package:jansof/screens/interctionappbar.dart';
import 'package:jansof/screens/saraswathi.dart';
import 'package:jansof/screens/scrollcolorappbar.dart';
import 'package:jansof/screens/shapesappbar.dart';
import 'package:jansof/screens/sliverappbar.dart';
import 'package:jansof/screens/toggletitleappbar.dart';
import 'package:jansof/screens/visiopaappbar.dart';
import 'package:jansof/swapsappbar.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Hello World',

      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Futura',
        primarySwatch: Colors.teal,
      ),
      // A widget which will be started on application startup

      // home: DefaultTabController(length: 4, child: homerag()),
      // home: DefaultTabController(length: 4, child: dashboard()),
      // home: DefaultTabController(length: 4, child: homescreen()),
      // home: sliver(),
      // home: action(),
      // home: const DefaultTabController(length: 2, child: checking()),
      // home: flexible(),
      // home: toggledappBar(),
      // home: scrollcolorappBar(),
      // home: dynamicappbar(),
      // home: dynamics(),
      // home: animatedappbar(),
      // home: visiOpaappbar(),
      // home: swapsappbar(),
      // home: flexspacebar(),

      // home: BottomToggleAppBar(),
      //
      //
      // home: taptrigered(),
      // home: gestureappbar(),
      // home: focusappbar(),
      home: HomeScreen(),

      // home: sarswathi(),
    );
  }
}

// class MyHomePage extends StatelessWidget {
//   final String title;
//   const MyHomePage({super.key, required this.title});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         // The title text which will be shown on the action bar
//         title: Text(title),
//       ),
//       body: Center(
//         child: Text(
//           'Hello, World!',
//         ),
//       ),
//     );
//   }
// }
