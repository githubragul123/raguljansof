import 'package:flutter/material.dart';

class swapsappbar extends StatefulWidget {
  const swapsappbar({Key? key}) : super(key: key);

  @override
  State<swapsappbar> createState() => _swapsappbarState();
}

class _swapsappbarState extends State<swapsappbar> {
  bool isSearching = false;
  String currentPage = "Home";

  final TextEditingController searchController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            elevation: 2,
            leading: isSearching
                ? IconButton(
                    icon: const Icon(Icons.arrow_back),
                    onPressed: () {
                      setState(() {
                        isSearching = false;
                        searchController.clear();
                      });
                    },
                  )
                : IconButton(
                    icon: Icon(Icons.menu),
                    onPressed: () {
                      setState(() {});
                    }),
            title: isSearching
                ? TextField(
                    controller: searchController,
                    autofocus: true,
                    decoration: const InputDecoration(
                      hintText: "Search..",
                      border: InputBorder.none,
                    ),
                  )
                : Text(currentPage),
            actions: [
              IconButton(
                  icon: Icon(isSearching ? Icons.close : Icons.search),
                  onPressed: () {
                    setState(() {
                      isSearching = !isSearching;
                      searchController.clear();
                    });
                  })
            ]),
        body: Center(
          child: Text(
            " Current page $currentPage",
            style: const TextStyle(fontSize: 22),
          ),
        ));
  }
}
