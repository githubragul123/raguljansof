class AuthService {
  static bool isLoggedIn = false;
  static bool get isLogged => isLoggedIn;

  static void login() {
    isLoggedIn = true;
  }

  static void logout() {
    isLoggedIn = false;
  }
}
