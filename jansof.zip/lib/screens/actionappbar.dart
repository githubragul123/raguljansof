import 'package:flutter/material.dart';

class action extends StatelessWidget {
  const action({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(kToolbarHeight + 45),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: AppBar(
              elevation: 15,
              shadowColor: Colors.red,
              surfaceTintColor: Colors.red,
              toolbarHeight: 67,
              titleSpacing: 5,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.elliptical(19, 59))),
              leading:
                  IconButton(icon: Icon(Icons.arrow_back), onPressed: () {}),
              centerTitle: true,
              title: Text(
                'action bar',
              ),
              actions: [
                IconButton(icon: Icon(Icons.search), onPressed: () {}),
                PopupMenuButton(
                    itemBuilder: (context) => [
                          PopupMenuItem(
                            child: Text('setting'),
                          )
                        ])
              ]),
        ),
      ),
    );
  }
}
