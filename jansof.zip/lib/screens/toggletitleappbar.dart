import 'package:flutter/material.dart';

class toggledappBar extends StatefulWidget {
  const toggledappBar({Key? key}) : super(key: key);

  @override
  State<toggledappBar> createState() => _toggledappBarState();
}

class _toggledappBarState extends State<toggledappBar> {
  bool isToggled = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(title: isToggled ? Text('rahul') : Text('id'), actions: [
      IconButton(
          icon: isToggled ? Icon(Icons.message) : Icon(Icons.send),
          onPressed: () {
            setState(() {
              isToggled = !isToggled;
            });
          }),
    ]));
  }
}
