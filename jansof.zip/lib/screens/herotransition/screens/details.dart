// detail_screen.dart
import 'package:flutter/material.dart';

class DetailScreen extends StatelessWidget {
  const DetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.red,
      body: Column(
        children: [
          Hero(
            tag: "appbar-image",
            child: Image.network(
              "https://images.unsplash.com/photo-1507525428034-b723cf961d3e",
              height: 300,
              width: double.infinity,
              fit: BoxFit.cover,
            ),
          ),
          const SizedBox(height: 20),
          const Text("Detail Screen", style: TextStyle(fontSize: 24)),
          const SizedBox(height: 20),
          ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('go beck'))
        ],
      ),
    );
  }
}
