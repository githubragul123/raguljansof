import 'package:flutter/material.dart';
import 'package:jansof/screens/herotransition/screens/details.dart';
import 'package:jansof/screens/herotransition/widgets/pro_app_bar.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: CustomScrollView(slivers: [
      ProAppBar(),
      SliverList(
        delegate: SliverChildBuilderDelegate(
          (context, index) => ListTile(
              title: Text('ragul $index'),
              onTap: () {
                Navigator.push(
                    context,
                    PageRouteBuilder(
                      transitionDuration: const Duration(seconds: 10),
                      pageBuilder: (
                        _,
                        __,
                        ___,
                      ) =>
                          const DetailScreen(),
                      transitionsBuilder:
                          (context, animation, secondaryAnimation, child) {
                        const begin = Offset(1.0, 0.0);
                        const end = Offset(0.0, 0.0);
                        const curve = Curves.easeInOut;

                        var tween = Tween(
                          begin: begin,
                          end: end,
                        );
                        var curvedAnimation = CurvedAnimation(
                          parent: animation,
                          curve: curve,
                        );
                        // return SlideTransition(
                        //     // position: tween.animate(curvedAnimation),
                        //     child: child);
                        //
                        // return FadeTransition(opacity: animation, child: child);
                        //
                        // return ScaleTransition(scale: animation, child: child);
                        //
                        return RotationTransition(
                            turns: animation, child: child);
                      },
                    ));
              }),
          childCount: 34,
        ),
      )
    ]));
  }
}
