// pro_app_bar.dart
import 'package:flutter/material.dart';

class ProAppBar extends StatelessWidget {
  const ProAppBar({super.key});

  @override
  Widget build(BuildContext context) {
    return SliverAppBar(
      expandedHeight: 250,
      pinned: true,
      flexibleSpace: FlexibleSpaceBar(
        background: Hero(
          tag: "appbar-image",
          child: Image.network(
            "https://images.unsplash.com/photo-1507525428034-b723cf961d3e",
            fit: BoxFit.cover,
          ),
        ),
        title: const Text("Saraswathi"),
      ),
    );
  }
}
