import 'package:flutter/material.dart';

class taptrigered extends StatefulWidget {
  const taptrigered({Key? key}) : super(key: key);

  @override
  State<taptrigered> createState() => _taptrigeredState();
}

class _taptrigeredState extends State<taptrigered>
    with SingleTickerProviderStateMixin {
  bool isSearching = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            backgroundColor: Colors.red,
            title: AnimatedSwitcher(
              duration: const Duration(seconds: 5),
              child: isSearching
                  ? TextField(
                      key: ValueKey('search'),
                      decoration: const InputDecoration(
                        hintText: 'search...',
                        border: InputBorder.none,
                      ),
                      autofocus: true,
                    )
                  : Text('home', key: ValueKey('title')),
            ),
            actions: [
              IconButton(
                  icon: AnimatedSwitcher(
                    duration: Duration(seconds: 5),
                    child: isSearching
                        ? Icon(Icons.close, key: ValueKey('close'))
                        : Icon(
                            Icons.search,
                            key: ValueKey('searchIcon'),
                          ),
                  ),
                  onPressed: () {
                    setState(() {
                      isSearching = !isSearching;
                    });
                  })
            ]),
        body: Center(child: Text('taptriggered app bar')));
  }
}

class gestureappbar extends StatefulWidget {
  const gestureappbar({Key? key}) : super(key: key);

  @override
  State<gestureappbar> createState() => _gestureappbarState();
}

class _gestureappbarState extends State<gestureappbar> {
  double appbarheight = kToolbarHeight;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Column(children: [
      GestureDetector(
          onVerticalDragUpdate: (details) {
            print(details.delta.dy);
            setState(() {
              appbarheight += details.delta.dy;
              // appbarheight = appbarheight.clamp(appbarheight, 400.0);
            });
          },
          child: AnimatedContainer(
            decoration: BoxDecoration(color: Colors.blue),
            duration: Duration(milliseconds: 300),
            height: appbarheight,
            alignment: Alignment.center,
            child: Text('Height:${appbarheight.toStringAsFixed(0)}',
                style: TextStyle(
                    color: Colors.red,
                    fontSize: 23,
                    fontWeight: FontWeight.bold)),
          )),
      const Expanded(child: const Text('drag/up and down'))
    ]));
  }
}

class focusappbar extends StatefulWidget {
  const focusappbar({Key? key}) : super(key: key);

  @override
  State<focusappbar> createState() => _focusappbarState();
}

class _focusappbarState extends State<focusappbar> {
  final FocusNode searchFocus = FocusNode();
  bool hasFocus = false;

  @override
  void initState() {
    super.initState();
    searchFocus.addListener(() {
      setState(() {
        hasFocus = searchFocus.hasFocus;
      });
    });
  }

  @override
  void dispose() {
    searchFocus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: PreferredSize(
            preferredSize: Size.fromHeight(hasFocus ? 250 : 200),
            child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                padding: EdgeInsets.symmetric(horizontal: 20, vertical: 23),
                color: Colors.yellow,
                child: Column(children: [
                  if (!hasFocus)
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Focusappbar',
                        style: TextStyle(color: Colors.red, fontSize: 50),
                      ),
                    ),
                  TextField(
                    focusNode: searchFocus,
                    autocorrect: true,
                    decoration: InputDecoration(
                        hintText: 'search..',
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(23)),
                        filled: true,
                        fillColor: Colors.white,
                        suffixIcon: hasFocus
                            ? IconButton(
                                icon: Icon(Icons.close),
                                onPressed: (() {
                                  searchFocus.unfocus();
                                }))
                            : null),
                  )
                ]))),
        body: Center(child: const Text('FocusAppBar')));
  }
}
