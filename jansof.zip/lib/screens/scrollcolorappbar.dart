import 'package:flutter/material.dart';

class scrollcolorappBar extends StatefulWidget {
  const scrollcolorappBar({Key? key}) : super(key: key);

  @override
  State<scrollcolorappBar> createState() => _scrollcolorappBarState();
}

class _scrollcolorappBarState extends State<scrollcolorappBar> {
  Color appBarColor = Colors.transparent;
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();

    _scrollController.addListener(() {
      if (_scrollController.offset > 50) {
        setState(() {
          appBarColor = Colors.blue;
        });
      } else {
        setState(() {
          appBarColor = Colors.transparent;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: appBarColor,
          title: Text('ragul'),
          centerTitle: true,
        ),
        body: ListView.builder(
            controller: _scrollController,
            itemCount: 30,
            itemBuilder: (context, index) {
              return ListTile(title: Text('item $index'));
            }));
  }
}
