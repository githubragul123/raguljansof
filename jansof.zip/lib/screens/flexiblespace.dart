import 'package:flutter/material.dart';

class flexible extends StatelessWidget {
  const flexible({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: CustomScrollView(slivers: [
      SliverAppBar(
          expandedHeight: 209,
          pinned: true,
          flexibleSpace: FlexibleSpaceBar(
              title: Text('flexible'),
              centerTitle: true,
              background: Image.asset(
                'assets/images.png',
                fit: BoxFit.cover,
              ))),
      SliverList(
          delegate: SliverChildBuilderDelegate(
        (BuildContext, int index) {
          return ListTile(title: Text('Item #$index'));
        },
        childCount: 50,
      ))
    ]));
  }
}
