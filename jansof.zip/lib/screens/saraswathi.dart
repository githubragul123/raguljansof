import 'package:flutter/material.dart';

class sarswathi extends StatefulWidget {
  const sarswathi({Key? key}) : super(key: key);

  @override
  State<sarswathi> createState() => _sarswathiState();
}

class _sarswathiState extends State<sarswathi> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          backgroundColor: Colors.grey.shade300,
          title: Text('saraswathi',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 43,
                color: Colors.blue,
              )),
          centerTitle: true,
          actions: [IconButton(icon: Icon(Icons.search), onPressed: () {})]),
      body: Center(
        child: Text('ammu',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 43,
              color: Colors.green,
            )),
      ),
    );
  }
}
