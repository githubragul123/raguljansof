import 'package:flutter/material.dart';

import '../service/auth_service.dart';

class dynamics extends StatefulWidget {
  const dynamics({Key? key}) : super(key: key);

  @override
  State<dynamics> createState() => _dynamicsState();
}

class _dynamicsState extends State<dynamics> {
  void _handleAuthAction() {
    setState(() {
      if (AuthService.isLoggedIn) {
        AuthService.logout();
      } else {
        AuthService.login();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: Text(
            AuthService.isLoggedIn ? 'Dashboard' : 'Welcome',
          ),
          actions: [
            IconButton(
                icon: Icon(AuthService.isLoggedIn ? Icons.logout : Icons.login),
                onPressed: _handleAuthAction)
          ]),
      body: Center(
          child:
              Text(AuthService.isLoggedIn ? ' User logIn' : ' user log out')),
    );
  }
}
