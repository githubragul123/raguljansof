import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

class visiOpaappbar extends StatefulWidget {
  const visiOpaappbar({Key? key}) : super(key: key);

  @override
  State<visiOpaappbar> createState() => _visiOpaappbarState();
}

class _visiOpaappbarState extends State<visiOpaappbar> {
  final ScrollController _scrollController = ScrollController();
  double titleOpacity = 1.0;

  bool showAppBar = true;

  bool manualOverride = false;

  @override
  void initState() {
    super.initState();

    _scrollController.addListener(() {
      if (_scrollController.position.userScrollDirection ==
          ScrollDirection.reverse) {
        setState(() {
          showAppBar = false;
          titleOpacity = 0.0;
        });
      } else if (_scrollController.position.userScrollDirection ==
          ScrollDirection.forward) {
        setState(() {
          showAppBar = true;
          titleOpacity = 1.0;
        });
      }
    });
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  @override
  void toggleTitleManually() {
    setState(() {
      manualOverride = true;
      titleOpacity = titleOpacity == 1.0 ? 0.0 : 1.0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(showAppBar ? kToolbarHeight : 0),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            child: AppBar(
              title: AnimatedOpacity(
                  opacity: titleOpacity,
                  duration: Duration(milliseconds: 300),
                  child: Text('visiOpa')),
              actions: showAppBar
                  ? [
                      IconButton(
                        icon: const Icon(Icons.search),
                        onPressed: () {},
                      ),
                      IconButton(
                        icon: const Icon(Icons.more_vert),
                        onPressed: () {},
                      ),
                    ]
                  : [],
            ),
          ),
        ),
        floatingActionButton: FloatingActionButton(
            onPressed: toggleTitleManually,
            child: Icon(
                titleOpacity == 1.0 ? Icons.visibility_off : Icons.visibility)),
        body: ListView.builder(
            controller: _scrollController,
            itemCount: 40,
            itemBuilder: (context, index) {
              return ListTile(title: Text('liset $index'));
            }));
  }
}
