import 'dart:html';

import 'package:flutter/material.dart';

class homerag extends StatelessWidget {
  homerag({Key? key}) : super(key: key);

  final _searchText = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _appBar(),
      body: TabBarView(children: [
        _tabBarViewItem(Icons.home, 'ragul jansof'),
        _tabBarViewItem(Icons.message, 'hi,ragul'),
        _tabBarViewItem(Icons.favorite, 'its my favorite'),
        _tabBarViewItem(Icons.person, 'ragul bio'),
      ]),
    );
  }

  PreferredSize _appBar() {
    return PreferredSize(
        preferredSize: const Size.fromHeight(150),
        child: Container(
            margin: const EdgeInsets.only(top: 5),
            padding: const EdgeInsets.symmetric(horizontal: 15),
            decoration: _boxDecoration(),
            child: SafeArea(
              child: Column(
                children: [
                  _topBar(),
                  const SizedBox(height: 10),
                  _searchBox(),
                  const SizedBox(height: 10),
                  _tabBar(),
                ],
              ),
            )));
  }

  BoxDecoration _boxDecoration() {
    return BoxDecoration(
      borderRadius: const BorderRadius.vertical(bottom: Radius.circular(35)),
      gradient: LinearGradient(
        colors: [Colors.white, Colors.teal.shade100],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ),
    );
  }

  Widget _topBar() {
    return Row(
      children: [
        Image.asset(
          'assets/images.png',
          scale: 07,
        ),
        const Expanded(
            child: Text('ragul jansof',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 15, color: Colors.black))),
        const CircleAvatar(
            radius: 15, backgroundImage: AssetImage('assets/images.png')),
      ],
    );
  }

  Widget _searchBox() {
    return SizedBox(
      height: 35,
      child: TextFormField(
        controller: _searchText,
        decoration: InputDecoration(
            filled: true,
            fillColor: Colors.white,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
            hintText: 'search...',
            contentPadding: const EdgeInsets.all(1),
            prefixIcon: const Icon(Icons.search),
            suffixIcon: InkWell(
                child: const Icon(Icons.close),
                onTap: () {
                  _searchText.clear();
                })),
      ),
    );
  }

  Widget _tabBar() {
    return TabBar(
      labelPadding: const EdgeInsets.all(0),
      labelColor: Colors.black,
      indicatorColor: Colors.black,
      unselectedLabelColor: Colors.teal.shade800,
      tabs: [
        const Tab(iconMargin: EdgeInsets.all(0), icon: Icon(Icons.home)),
        const Tab(iconMargin: EdgeInsets.all(0), icon: Icon(Icons.message)),
        const Tab(iconMargin: EdgeInsets.all(0), icon: Icon(Icons.favorite)),
        const Tab(iconMargin: EdgeInsets.all(0), icon: Icon(Icons.person)),
      ],
    );
  }

  Widget _tabBarViewItem(IconData icon, String name) {
    return Column(
      children: [
        Icon(
          icon,
          size: 200,
        ),
        Text(
          name,
          style: TextStyle(fontSize: 23),
        )
      ],
    );
  }
}
