import 'package:flutter/material.dart';

class sliver extends StatelessWidget {
  const sliver({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(slivers: [
        SliverAppBar(
          expandedHeight: 100,
          pinned: true,
          floating: true,
          flexibleSpace: Container(
            decoration: BoxDecoration(
                borderRadius: BorderRadius.vertical(
                  top: Radius.circular(20),
                ),
                gradient: LinearGradient(colors: [
                  Colors.white,
                  Colors.blue,
                ], begin: Alignment.topCenter, end: Alignment.bottomCenter)),
          ),
        ),
        SliverList(
            delegate: SliverChildBuilderDelegate(
          (BuildContext, int index) {
            return ListTile(title: Text('Item #$index'));
          },
          childCount: 50,
        ))
      ]),
    );
  }
}
