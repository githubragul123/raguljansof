import 'package:flutter/material.dart';

class animatedappbar extends StatefulWidget {
  const animatedappbar({Key? key}) : super(key: key);

  @override
  State<animatedappbar> createState() => _animatedappbarState();
}

class _animatedappbarState extends State<animatedappbar> {
  bool isExpanded = false;

  void _animatedhandle() {
    setState(() {
      isExpanded = !isExpanded;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: PreferredSize(
            preferredSize: Size.fromHeight(isExpanded ? 120 : 56),
            child: AnimatedContainer(
              decoration: BoxDecoration(
                  border: Border.all(color: Colors.blue, width: 4)),
              duration: Duration(milliseconds: 300),
              margin: EdgeInsets.symmetric(
                  horizontal: isExpanded ? 12 : 0,
                  vertical: isExpanded ? 8 : 0),
              padding: EdgeInsets.symmetric(horizontal: isExpanded ? 0 : 0),
              child: AppBar(
                  backgroundColor: Colors.red,
                  title: AnimatedAlign(
                      duration: Duration(milliseconds: 300),
                      alignment: isExpanded
                          ? Alignment.topLeft
                          : Alignment.bottomRight,
                      child: Text('animated appBar')),
                  centerTitle: true,
                  actions: [
                    AnimatedPadding(
                      duration: Duration(milliseconds: 300),
                      padding: EdgeInsets.only(right: isExpanded ? 23 : 0),
                      child: IconButton(
                          icon: Icon(Icons.expand), onPressed: _animatedhandle),
                    )
                  ]),
            )),
        body: Center(child: Text('tamil')));
  }
}
