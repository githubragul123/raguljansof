import 'package:flutter/material.dart';

class shapesappbar extends StatefulWidget {
  const shapesappbar({Key? key}) : super(key: key);

  @override
  State<shapesappbar> createState() => _shapesappbarState();
}

class _shapesappbarState extends State<shapesappbar> {
  double radius = 32;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.indigo,
        clipBehavior: Clip.antiAlias,
        flexibleSpace: Image.network(
          'https://picsum.photos/600',
          fit: BoxFit.cover,
        ),
        shape: RoundedRectangleBorder(
            borderRadius:
                BorderRadius.vertical(bottom: Radius.circular(radius))),
        title: const Text('dynamic Shape'),
      ),
      body: NotificationListener<ScrollNotification>(
        onNotification: (scroll) {
          setState(() {
            radius = scroll.metrics.pixels > 20 ? 0 : 32;
          });
          return true;
        },
        child: ListView.builder(
            itemCount: 30,
            itemBuilder: (_, i) => ListTile(title: Text('Item $i'))),
      ),
    );
  }
}

class BottomToggleAppBar extends StatefulWidget {
  const BottomToggleAppBar({Key? key}) : super(key: key);

  @override
  State<BottomToggleAppBar> createState() => _BottomToggleAppBarState();
}

class _BottomToggleAppBarState extends State<BottomToggleAppBar> {
  bool showBottom = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        title: const Text('Dynamic Bottom'),
        bottom: showBottom
            ? PreferredSize(
                preferredSize: const Size.fromHeight(48),
                child: Container(
                  height: 48,
                  alignment: Alignment.center,
                  child: const Text(
                    'Filter Options',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              )
            : null,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            showBottom = !showBottom;
          });
        },
        child: const Icon(Icons.swap_vert),
      ),
    );
  }
}
