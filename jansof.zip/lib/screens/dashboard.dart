import 'dart:html';

import 'package:flutter/material.dart';

class dashboard extends StatelessWidget {
  dashboard({Key? key}) : super(key: key);

  final _searchText = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          appBar: _appBar(),
          body: TabBarView(
            children: [
              _tabBarViewItem(Icons.home, 'ragul jansof'),
              _tabBarViewItem(Icons.message, 'hi'),
              _tabBarViewItem(Icons.favorite, 'you are my favorite person'),
              _tabBarViewItem(Icons.person, 'profile')
            ],
          )),
    );
  }

  PreferredSize _appBar() {
    return PreferredSize(
      preferredSize: Size.fromHeight(150),
      child: Container(
          margin: EdgeInsets.only(top: 5),
          padding: EdgeInsets.symmetric(horizontal: 15),
          decoration: _boxDecoration(),
          child: Column(
            children: [
              _topBar(),
              SizedBox(height: 10),
              _searchBox(),
              SizedBox(height: 5),
              _tabBar(),
            ],
          )),
    );
  }

  BoxDecoration _boxDecoration() {
    return BoxDecoration(
        borderRadius: const BorderRadius.vertical(bottom: Radius.circular(24)),
        gradient: LinearGradient(
          colors: [
            Colors.white,
            Colors.teal.shade100,
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ));
  }

  Widget _topBar() {
    return Row(children: [
      Image.asset(
        'assets/images.png',
        scale: 07,
      ),
      const Expanded(
          child: Text('palani',
              textAlign: TextAlign.center, style: TextStyle(fontSize: 15))),
      CircleAvatar(
        radius: 15,
        backgroundImage: const AssetImage('assets/images.png'),
      )
    ]);
  }

  Widget _searchBox() {
    return SizedBox(
        child: TextFormField(
            controller: _searchText,
            decoration: InputDecoration(
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                hintText: 'search...',
                contentPadding: EdgeInsets.all(15),
                prefixIcon: Icon(Icons.search),
                suffixIcon: InkWell(
                    child: Icon(Icons.clear),
                    onTap: () {
                      _searchText.clear();
                    }))));
  }

  Widget _tabBar() {
    return TabBar(
      labelPadding: EdgeInsets.all(0),
      labelColor: Colors.black,
      indicatorColor: Colors.black,
      unselectedLabelColor: Colors.teal.shade800,
      tabs: [
        Tab(
          iconMargin: const EdgeInsets.all(0),
          icon: Icon(Icons.home),
        ),
        const Tab(iconMargin: EdgeInsets.all(0), icon: Icon(Icons.message)),
        const Tab(iconMargin: EdgeInsets.all(0), icon: Icon(Icons.favorite)),
        const Tab(iconMargin: EdgeInsets.all(0), icon: Icon(Icons.person)),
      ],
    );
  }

  Widget _tabBarViewItem(IconData icon, String name) {
    return Center(
      child: Column(
        children: [
          Icon(icon, size: 200),
          Text(
            name,
          ),
        ],
      ),
    );
  }
}
