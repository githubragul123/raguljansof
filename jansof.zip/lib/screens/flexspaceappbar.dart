import 'dart:core';
import 'dart:ui';

import 'package:flutter/material.dart';

class flexspacebar extends StatelessWidget {
  const flexspacebar({Key? key}) : super(key: key);

  static const double maxAppBarHeight = 320;
  static const double minAppBarHeight = kToolbarHeight + 24;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: CustomScrollView(slivers: [
      SliverAppBar(
        expandedHeight: maxAppBarHeight,
        pinned: true,
        stretch: true,
        backgroundColor: Colors.black,
        stretchTriggerOffset: 100,
        flexibleSpace: LayoutBuilder(
          builder: (context, constraints) {
            final double height = constraints.biggest.height;

            final double t = ((height - minAppBarHeight) /
                    (maxAppBarHeight - minAppBarHeight))
                .clamp(0.0, 1.0);
            final double blur = lerpDouble(12, 0, t)!;
            final double overlayOpacity = lerpDouble(0.6, 0.15, t)!;

            return Stack(
              fit: StackFit.expand,
              children: [
                Image.network(
                  'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee',
                  fit: BoxFit.cover,
                ),
                // BackdropFilter(
                //     // filter: ImageFilter.blur(
                //     //   sigmaX: blur,
                //     //   sigmaY: blur,
                //     // ),
                //     child: Container(color: Colors.transparent)),
                Container(color: Colors.black.withOpacity(overlayOpacity)),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.deepPurple.withOpacity(0.6 * t),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
                FlexibleSpaceBar(
                  collapseMode: CollapseMode.parallax,
                  stretchModes: const [
                    StretchMode.zoomBackground,
                    // StretchMode.blurBackground,
                  ],
                  titlePadding: const EdgeInsets.only(left: 16, bottom: 16),
                  title: Text('Advanced AppBar',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: lerpDouble(20, 16, 1 - t))),
                ),
              ],
            );
          },
        ),
      ),
      SliverList(
        delegate: SliverChildBuilderDelegate(
          (context, index) => ListTile(title: Text('List Item ${index + 1}')),
          childCount: 30,
        ),
      )
    ]));
  }
}
