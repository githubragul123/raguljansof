import 'package:flutter/material.dart';

class dynamicappbar extends StatefulWidget {
  @override
  State<dynamicappbar> createState() => _dynamicappbarState();
}

class _dynamicappbarState extends State<dynamicappbar> {
  bool isLoggedIn = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Dynamic AppBar'),
          actions: isLoggedIn
              ? [
                  IconButton(
                    icon: Icon(Icons.logout),
                    onPressed: () {
                      setState(() {
                        isLoggedIn = false;
                      });
                    },
                  )
                ]
              : [
                  IconButton(
                      icon: Icon(Icons.login),
                      onPressed: () {
                        setState(() {
                          isLoggedIn = true;
                        });
                      })
                ],
        ),
        body: Center(
            child: Text(
          isLoggedIn ? 'User logged In' : 'User logged Out',
          style: TextStyle(fontSize: 20),
        )));
  }
}
