import 'package:flutter/material.dart';

class homescreen extends StatelessWidget {
  homescreen({Key? key}) : super(key: key);

  final _searchText = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: _appBar(),
        body: TabBarView(
          children: [
            _tabBarViewItem(Icons.home, 'hi,welcome to the app'),
            _tabBarViewItem(Icons.message, 'i wants to talk with you'),
            _tabBarViewItem(Icons.favorite, 'yor are my favorite person'),
            _tabBarViewItem(Icons.person, 'its my profile')
          ],
        ));
  }

  PreferredSize _appBar() {
    return PreferredSize(
      preferredSize: const Size.fromHeight(155),
      child: Container(
          margin: const EdgeInsets.only(top: 5),
          padding: const EdgeInsets.symmetric(horizontal: 15),
          decoration: _boxDecoration(),
          child: Column(
            children: [
              _topBar(),
              const SizedBox(height: 10),
              _searchBox(),
              const SizedBox(height: 5),
              _tabBar(),
            ],
          )),
    );
  }

  BoxDecoration _boxDecoration() {
    return BoxDecoration(
      borderRadius: const BorderRadius.vertical(bottom: Radius.circular(15)),
      gradient: LinearGradient(
        colors: [
          Colors.white,
          Colors.red.shade800,
        ],
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
      ),
    );
  }

  Widget _topBar() {
    return Row(
      children: [
        Image.asset('assets/images.png', scale: 07),
        const Expanded(
            child: Text(
          'jeevitha',
          textAlign: TextAlign.center,
        )),
        const CircleAvatar(backgroundImage: AssetImage('assets/images.png')),
      ],
    );
  }

  Widget _searchBox() {
    return SizedBox(
        height: 35,
        child: TextFormField(
            controller: _searchText,
            decoration: InputDecoration(
                filled: true,
                fillColor: Colors.white,
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(15)),
                hintText: 'search...',
                prefixIcon: const Icon(Icons.search),
                contentPadding: const EdgeInsets.all(15),
                suffixIcon: InkWell(
                    child: const Icon(Icons.clear),
                    onTap: () {
                      _searchText.clear();
                    }))));
  }

  Widget _tabBar() {
    return const TabBar(
      labelColor: Colors.black,
      indicatorColor: Colors.black,
      unselectedLabelColor: Colors.white,
      tabs: [
        Tab(iconMargin: EdgeInsets.all(0), icon: Icon(Icons.home)),
        Tab(iconMargin: EdgeInsets.all(0), icon: Icon(Icons.message)),
        Tab(iconMargin: EdgeInsets.all(0), icon: Icon(Icons.favorite)),
        Tab(
          iconMargin: EdgeInsets.all(0),
          icon: Icon(Icons.person),
        )
      ],
    );
  }

  Widget _tabBarViewItem(IconData icon, String name) {
    return Center(
      child: Column(
        children: [
          Icon(
            icon,
            size: 200,
          ),
          Text(
            name,
          )
        ],
      ),
    );
  }
}
