import 'package:flutter/material.dart';

class checking extends StatelessWidget {
  const checking({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.blue,
        appBar: AppBar(
            forceMaterialTransparency: false,
            elevation: 34,
            shadowColor: Colors.green.shade900,
            backgroundColor: Colors.orange,
            automaticallyImplyLeading: true,
            title: Text('luma'),
            centerTitle: true,
            excludeHeaderSemantics: true,
            bottomOpacity: 0.9,
            bottom: TabBar(tabs: [Text('ragul'), Text('uma')]),
            scrolledUnderElevation: 7.0,
            notificationPredicate: (ScrollNotification notification) {
              return notification.depth == 0;
            }),
        body: ListView.builder(
            itemCount: 57,
            itemBuilder: (_, i) => ListTile(title: Text('ragul $i'))));
  }
}
